# Goticismo medieval

Apresentação de 11 slides sobre o gótico medieval, do século XII ao XV. Ela cobre as cidades e universidades, a arquitetura, a escultura, o vitral e a iluminura, a escolástica, a literatura e a música, e a história do próprio nome "gótico".

## Ver a apresentação

Abra `docs/index.html` no navegador.

- Setas, espaço ou clique passam os slides.
- `N` mostra as notas do apresentador.
- `F` abre em tela cheia.

Para publicar na web, ligue o GitHub Pages em Settings > Pages, com a branch `main` e a pasta `/docs`. O endereço fica `https://SEU-USUARIO.github.io/goticismo-medieval/`.

## O que tem aqui

```
docs/index.html   apresentação pronta para abrir ou publicar
notas.md          notas do apresentador, slide por slide
fonte/            arquivos de origem dos slides (deck.json, deck.css e um HTML por slide)
```

Para mudar um slide, edite o HTML em `fonte/slides/` e o estilo em `fonte/deck.css`. O `docs/index.html` foi gerado a partir desses arquivos, então ele precisa ser refeito depois de qualquer edição.

## Conferir antes de apresentar

As notas trazem a marca [CONFERIR] nos pontos que dependem de fonte. Vale checar com o seu material:

- Datas do coro de Saint-Denis (1140 a 1144) e o fim do gótico em cada país
- Início e fim das obras de Notre-Dame de Paris (1163 e c. 1345)
- Datas dos portais de Chartres e Reims
- Datação das Très Riches Heures
- Panofsky, *Gothic Architecture and Scholasticism* (1951)
- Datas das obras de Dante e Chaucer e da escola de Notre-Dame
- O uso do termo "gótico" por Vasari, e as datas de Victor Hugo e Viollet-le-Duc

Os desenhos (arcos, vitral) são esquemáticos, não plantas reais.

## Autoria

Texto e layout gerados com o Claude, da Anthropic. Revise os fatos antes de usar.

## Licença

Ainda não definida. Escolha uma antes de publicar, se quiser que outras pessoas possam reutilizar.

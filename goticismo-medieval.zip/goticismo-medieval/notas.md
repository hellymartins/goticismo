# Notas do apresentador

## 1. Goticismo medieval

Quando se fala em gótico, quase todo mundo pensa numa catedral. A catedral é a parte mais visível, mas o gótico foi muito maior: mudou a escultura, a pintura, o pensamento, a literatura e até a música. Vou passar por cada uma dessas frentes.

## 2. O que foi o gótico, além das catedrais?

Gótico é o nome de uma época da Europa medieval, não só de um tipo de igreja. Nela mudou o jeito de construir, de fazer imagens, de pensar a fé e até de escrever. Cada slide a seguir pega uma dessas mudanças.

## 3. c. 1140 a 1500

O gótico começa por volta de 1140, na região de Paris, com a reconstrução do coro da abadia de Saint-Denis pelo abade Suger. Daí se espalha para Inglaterra, Alemanha, Espanha e Itália. O fim varia: na Itália o Renascimento chega cedo, em outros lugares o gótico dura até o século XVI. [CONFERIR: datas do coro de Saint-Denis, 1140 a 1144, e o limite final de cada país.]

## 4. O gótico é arte de cidade

O românico era uma arte de mosteiros e castelos. O gótico nasce quando as cidades crescem, com comércio, mercadores e as primeiras universidades, como Bolonha e Paris. A catedral vira obra de toda a cidade. Notre-Dame de Paris foi começada em 1163 e só ficou pronta por volta de 1345, então os primeiros construtores não chegaram a ver o resultado. [CONFERIR: 1163 e 1345.]

## 5. Na arquitetura, o peso foi para fora e a parede virou janela

Na arquitetura há quatro peças que trabalham juntas. O arco em ponta, comparado ao redondo, sobe mais na mesma largura e joga o peso mais para baixo. As nervuras de pedra formam o esqueleto do teto e levam o peso até os pilares. O arcobotante, do lado de fora, segura o empuxo das abóbadas. Com a parede aliviada, sobra espaço para o vitral.

## 6. Nos portais, a pedra ganhou corpo

A escultura saiu do capitel e foi para o portal. No portal real de Chartres, por volta de 1145, as figuras são alongadas e parecem presas às colunas. Cem anos depois, em Reims, as estátuas já têm gesto, peso de corpo e rosto individual. A pedra deixa de ser só ornamento e passa a contar a história. [CONFERIR: datas de Chartres e Reims.]

## 7. A cor passou da parede para o vidro e o pergaminho

Na pintura, o gótico se vê em dois lugares. Nos vitrais, que contam cenas da Bíblia e vidas de santos em painéis de vidro colorido. E nos livros ilustrados, as iluminuras. Os livros de horas eram livros de oração de gente rica, e as Très Riches Heures do duque de Berry, do início do século XV, são o exemplo mais famoso. [CONFERIR: datação das Très Riches Heures.]

## 8. Nas universidades, a fé passou a ser discutida com lógica

No pensamento, o gótico é a época da escolástica. Nas universidades, os mestres discutiam a fé com lógica. Tomás de Aquino escreveu a Suma Teológica no século XIII, dividida em perguntas, objeções e respostas. Em 1951, o historiador da arte Erwin Panofsky comparou isso à catedral gótica, em que tudo também é dividido e encaixado. Muita gente discute se o paralelo se sustenta. [CONFERIR: Panofsky, “Gothic Architecture and Scholasticism”, 1951.]

## 9. Dante e Chaucer escreveram na língua do povo

Na literatura, o gótico é a época em que línguas como o italiano e o inglês passam a ser usadas em obras grandes, e não só o latim. Dante concluiu a Divina Comédia por volta de 1320, e Chaucer escreveu os Contos de Canterbury no fim do século XIV. Na música, a escola de Notre-Dame, em Paris, desenvolveu a polifonia, entre cerca de 1160 e 1230. [CONFERIR: datas da escola de Notre-Dame e dos textos.]

## 10. O nome “gótico” veio depois, e como insulto

Ninguém na Idade Média dizia “gótico”. O nome foi dado depois, no Renascimento, por italianos como Vasari, que achavam a arte medieval bárbara, coisa dos godos. No século XIX o gosto virou: Victor Hugo publicou Notre-Dame de Paris em 1831 e Viollet-le-Duc restaurou a catedral. É dessa volta que vem o gótico das histórias de terror. [CONFERIR: o uso do termo por Vasari e as datas de Hugo e Viollet-le-Duc.]

## 11. Obrigado

Obrigado. Se um dia vocês entrarem numa catedral gótica, olhem para cima, mas olhem também para o portal e para o vitral. Quase tudo que vimos hoje está ali.
